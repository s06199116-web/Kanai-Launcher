package com.nova.launcher.util

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.core.content.ContextCompat
import com.nova.launcher.lock.LockService

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("kanai", Context.MODE_PRIVATE)

    fun lockEnabled(c: Context): Boolean = sp(c).getBoolean("lock_enabled", false)

    fun setLockEnabled(c: Context, value: Boolean) {
        sp(c).edit().putBoolean("lock_enabled", value).apply()
    }
}

object Torch {
    var isOn: Boolean = false
        private set

    /** Toggles the flashlight and returns the new state. */
    fun toggle(context: Context): Boolean {
        val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return isOn
        val target = !isOn
        try {
            cm.setTorchMode(id, target)
            isOn = target
        } catch (_: Exception) {
        }
        return isOn
    }
}

fun Context.safeStart(intent: Intent) {
    try {
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
    }
}

fun Context.setLockServiceRunning(on: Boolean) {
    val intent = Intent(this, LockService::class.java)
    if (on) ContextCompat.startForegroundService(this, intent) else stopService(intent)
    Prefs.setLockEnabled(this, on)
}
