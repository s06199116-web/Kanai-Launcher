package com.nova.launcher.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.nova.launcher.util.Prefs
import com.nova.launcher.util.safeStart
import com.nova.launcher.util.setLockServiceRunning

@Composable
fun SetupScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)

    var refresh by remember { mutableIntStateOf(0) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { refresh++ }

    val overlayOk = remember(refresh) { Settings.canDrawOverlays(ctx) }
    var lockOn by remember(refresh) { mutableStateOf(Prefs.lockEnabled(ctx)) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    Column(
        Modifier
            .fillMaxSize()
            .background(Kanai.scrim)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Setup",
                color = Kanai.textPrimary,
                fontSize = 28.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Kanai.textPrimary)
            }
        }

        StepCard(
            title = "1. Make Kanai your home app",
            body = "Pick Kanai Launcher as the default home app.",
            button = "Open home settings",
        ) { ctx.safeStart(Intent(Settings.ACTION_HOME_SETTINGS)) }

        StepCard(
            title = "2. Allow display over other apps",
            body = if (overlayOk) "Allowed. The lockscreen can appear when the screen turns off."
            else "Needed so the lockscreen can open itself when the screen turns off.",
            button = if (overlayOk) "Allowed" else "Grant permission",
            enabled = !overlayOk,
        ) {
            ctx.safeStart(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            )
        }

        if (Build.VERSION.SDK_INT >= 33) {
            StepCard(
                title = "3. Notifications",
                body = "Lets Android show the small \"lockscreen is active\" notification.",
                button = "Allow notifications",
            ) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
        }

        Column(
            Modifier
                .fillMaxWidth()
                .glass()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Kanai lockscreen", color = Kanai.textPrimary, fontWeight = FontWeight.Medium)
                    Text(
                        if (overlayOk) "Shows when you wake the phone." else "Grant step 2 first.",
                        color = Kanai.textSecondary,
                        fontSize = 13.sp,
                    )
                }
                Switch(
                    checked = lockOn,
                    enabled = overlayOk,
                    onCheckedChange = {
                        lockOn = it
                        ctx.setLockServiceRunning(it)
                    },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Kanai.accent,
                        checkedThumbColor = Kanai.onAccent,
                    ),
                )
            }
        }
    }
}

@Composable
private fun StepCard(
    title: String,
    body: String,
    button: String,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .glass()
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = Kanai.textPrimary, fontWeight = FontWeight.Medium)
        Text(body, color = Kanai.textSecondary, fontSize = 13.sp)
        Button(
            onClick = onClick,
            enabled = enabled,
            colors = ButtonDefaults.buttonColors(
                containerColor = Kanai.accent,
                contentColor = Kanai.onAccent,
            ),
        ) { Text(button) }
    }
}
