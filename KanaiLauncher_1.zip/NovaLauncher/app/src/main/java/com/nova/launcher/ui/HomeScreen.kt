package com.nova.launcher.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.launcher.data.AppInfo
import java.time.format.DateTimeFormatter

private val timeFmt = DateTimeFormatter.ofPattern("h:mm")
private val dateFmt = DateTimeFormatter.ofPattern("EEEE, d MMMM")

private fun greeting(hour: Int): String = when (hour) {
    in 5..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..20 -> "Good evening"
    else -> "Good night"
}

@Composable
fun HomeScreen(
    apps: List<AppInfo>,
    dock: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onOpenSetup: () -> Unit,
) {
    val dockPackages = dock.map { it.packageName }.toSet()
    val homeApps = apps.filter { it.packageName !in dockPackages }.take(12)

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 20.dp, vertical = 8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            IconButton(onClick = onOpenSetup) {
                Icon(Icons.Rounded.Settings, contentDescription = "Setup", tint = Kanai.textSecondary)
            }
        }
        ClockCard()
        Spacer(Modifier.height(24.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            userScrollEnabled = false,
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.weight(1f),
        ) {
            items(homeApps, key = { it.packageName }) { AppIcon(it, onLaunch) }
        }
        Text(
            "Swipe up for all apps  ·  swipe down for controls",
            color = Kanai.textSecondary,
            fontSize = 11.sp,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(vertical = 10.dp),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .glass(RoundedCornerShape(32.dp), strong = true)
                .padding(horizontal = 12.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            dock.forEach { AppIcon(it, onLaunch, showLabel = false) }
        }
    }
}

@Composable
fun ClockCard(modifier: Modifier = Modifier) {
    val now by rememberNow()
    Column(
        modifier
            .fillMaxWidth()
            .glass()
            .padding(24.dp)
    ) {
        Text(greeting(now.hour), color = Kanai.textSecondary, fontSize = 14.sp)
        Text(
            now.format(timeFmt),
            color = Kanai.textPrimary,
            fontSize = 68.sp,
            fontWeight = FontWeight.Light,
        )
        Text(
            now.format(dateFmt),
            color = Kanai.accent,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
        )
    }
}

@Composable
fun AppIcon(
    app: AppInfo,
    onLaunch: (AppInfo) -> Unit,
    showLabel: Boolean = true,
) {
    Column(
        Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable { onLaunch(app) }
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp)),
        )
        if (showLabel) {
            Text(
                app.label,
                color = Kanai.textPrimary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}
