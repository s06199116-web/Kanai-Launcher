package com.nova.launcher.lock

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.launcher.ui.Kanai
import com.nova.launcher.ui.glass
import com.nova.launcher.ui.rememberNow
import java.time.format.DateTimeFormatter

private val lockTimeFmt = DateTimeFormatter.ofPattern("h:mm")
private val lockDateFmt = DateTimeFormatter.ofPattern("EEEE, d MMMM")

@Composable
fun LockScreen(
    onUnlock: () -> Unit,
    onTorch: () -> Unit,
    onCamera: () -> Unit,
) {
    val now by rememberNow()
    var drag by remember { mutableFloatStateOf(0f) }

    val bounce by rememberInfiniteTransition(label = "hint").animateFloat(
        initialValue = 0f,
        targetValue = -10f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "bounce",
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Kanai.wallpaper)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        if (drag < -size.height * 0.2f) onUnlock()
                        drag = 0f
                    },
                    onDragCancel = { drag = 0f },
                ) { _, dy -> drag = (drag + dy).coerceAtMost(0f) }
            }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    translationY = drag * 0.5f
                    alpha = 1f - (-drag / size.height).coerceIn(0f, 0.8f)
                }
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(96.dp))
            Text(
                now.format(lockDateFmt),
                color = Kanai.accent,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
            )
            Text(
                now.format(lockTimeFmt),
                color = Kanai.textPrimary,
                fontSize = 96.sp,
                fontWeight = FontWeight.ExtraLight,
            )

            Spacer(Modifier.weight(1f))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                ShortcutButton(Icons.Rounded.FlashlightOn, "Torch", onTorch)
                ShortcutButton(Icons.Rounded.CameraAlt, "Camera", onCamera)
            }

            Column(
                Modifier
                    .padding(top = 28.dp, bottom = 20.dp)
                    .graphicsLayer { translationY = bounce },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Icon(
                    Icons.Rounded.KeyboardArrowUp,
                    contentDescription = null,
                    tint = Kanai.textSecondary,
                )
                Text("Swipe up to unlock", color = Kanai.textSecondary, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun ShortcutButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(56.dp)
            .glass(CircleShape, strong = true)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = Kanai.textPrimary)
    }
}
