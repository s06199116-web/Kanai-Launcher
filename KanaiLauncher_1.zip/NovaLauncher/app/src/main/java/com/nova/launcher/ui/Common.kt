package com.nova.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.time.LocalDateTime

/** Kanai's own palette: deep indigo into violet, rose and a warm amber glow. */
object Kanai {
    val wallpaper = Brush.verticalGradient(
        listOf(
            Color(0xFF14143A),
            Color(0xFF4B2FB5),
            Color(0xFFE5527A),
            Color(0xFFFFA25C),
        )
    )
    val glass = Color.White.copy(alpha = 0.16f)
    val glassStrong = Color.White.copy(alpha = 0.26f)
    val accent = Color(0xFFFFC46B)
    val onAccent = Color(0xFF2A1A00)
    val textPrimary = Color.White
    val textSecondary = Color.White.copy(alpha = 0.72f)
    val scrim = Color(0xEE0C0C26)
}

fun Modifier.glass(
    shape: Shape = RoundedCornerShape(28.dp),
    strong: Boolean = false,
): Modifier = this
    .clip(shape)
    .background(if (strong) Kanai.glassStrong else Kanai.glass)
    .border(1.dp, Color.White.copy(alpha = 0.18f), shape)

@Composable
fun rememberNow(): State<LocalDateTime> = produceState(initialValue = LocalDateTime.now()) {
    while (true) {
        value = LocalDateTime.now()
        delay(1000L)
    }
}

@Composable
fun KanaiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Kanai.accent),
        content = content,
    )
}
