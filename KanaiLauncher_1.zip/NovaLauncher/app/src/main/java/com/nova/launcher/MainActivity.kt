package com.nova.launcher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import com.nova.launcher.data.AppInfo
import com.nova.launcher.data.AppRepository
import com.nova.launcher.ui.AppDrawer
import com.nova.launcher.ui.ControlCenter
import com.nova.launcher.ui.HomeScreen
import com.nova.launcher.ui.Kanai
import com.nova.launcher.ui.KanaiTheme
import com.nova.launcher.ui.SetupScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Bumped whenever the Home button is pressed, so open panels can close. */
object HomeSignal {
    var presses by mutableIntStateOf(0)
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            KanaiTheme {
                KanaiRoot(onBrightness = { value ->
                    window.attributes = window.attributes.apply { screenBrightness = value }
                })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) HomeSignal.presses++
    }
}

@Composable
fun KanaiRoot(onBrightness: (Float) -> Unit) {
    val ctx = LocalContext.current

    var apps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.Default) { AppRepository.load(ctx) }
    }
    val dock = remember(apps) { AppRepository.dockApps(ctx, apps) }

    var showDrawer by remember { mutableStateOf(false) }
    var showControl by remember { mutableStateOf(false) }
    var showSetup by remember { mutableStateOf(false) }

    LaunchedEffect(HomeSignal.presses) {
        showDrawer = false
        showControl = false
        showSetup = false
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Kanai.wallpaper)
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (!showDrawer && !showControl && !showSetup) {
                            if (total < -120f) showDrawer = true
                            else if (total > 120f) showControl = true
                        }
                    },
                ) { _, dy -> total += dy }
            }
    ) {
        HomeScreen(
            apps = apps,
            dock = dock,
            onLaunch = { AppRepository.launch(ctx, it) },
            onOpenSetup = { showSetup = true },
        )

        AnimatedVisibility(
            visible = showDrawer,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            AppDrawer(
                apps = apps,
                onLaunch = { AppRepository.launch(ctx, it) },
                onClose = { showDrawer = false },
            )
        }

        AnimatedVisibility(
            visible = showControl,
            enter = slideInVertically { -it } + fadeIn(),
            exit = slideOutVertically { -it } + fadeOut(),
        ) {
            ControlCenter(onClose = { showControl = false }, onBrightness = onBrightness)
        }

        AnimatedVisibility(
            visible = showSetup,
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            SetupScreen(onClose = { showSetup = false })
        }
    }
}
