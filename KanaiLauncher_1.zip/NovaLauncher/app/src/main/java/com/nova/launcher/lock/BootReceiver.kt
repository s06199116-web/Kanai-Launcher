package com.nova.launcher.lock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.nova.launcher.util.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED &&
            Prefs.lockEnabled(context) &&
            Settings.canDrawOverlays(context)
        ) {
            ContextCompat.startForegroundService(context, Intent(context, LockService::class.java))
        }
    }
}
