package com.nova.launcher.lock

import android.app.KeyguardManager
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.nova.launcher.ui.KanaiTheme
import com.nova.launcher.util.Torch
import com.nova.launcher.util.safeStart

class LockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Appear above the system keyguard, but do not wake the screen by ourselves.
        setShowWhenLocked(true)
        setTurnScreenOn(false)
        enableEdgeToEdge()

        setContent {
            KanaiTheme {
                BackHandler {} // the lockscreen ignores Back
                LockScreen(
                    onUnlock = ::unlock,
                    onTorch = { Torch.toggle(this) },
                    onCamera = {
                        safeStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE))
                    },
                )
            }
        }
    }

    /**
     * If the phone has a PIN/pattern/fingerprint, Android asks for it here.
     * If not, the lockscreen simply closes.
     */
    private fun unlock() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    finish()
                }
            })
        } else {
            finish()
        }
    }
}
