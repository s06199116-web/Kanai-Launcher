package com.nova.launcher.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.AirplanemodeActive
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BrightnessHigh
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FlashlightOff
import androidx.compose.material.icons.rounded.FlashlightOn
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.launcher.util.Torch
import com.nova.launcher.util.safeStart
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

private data class Tile(
    val label: String,
    val icon: ImageVector,
    val active: Boolean,
    val onClick: () -> Unit,
)

private val ccTimeFmt = DateTimeFormatter.ofPattern("h:mm")
private val ccDateFmt = DateTimeFormatter.ofPattern("EEE, d MMM")

@Composable
fun ControlCenter(
    onClose: () -> Unit,
    onBrightness: (Float) -> Unit,
) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)

    val audio = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val wifi = remember { ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager }
    val now by rememberNow()

    var torchOn by remember { mutableStateOf(Torch.isOn) }
    var volume by remember {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max)
    }
    var brightness by remember { mutableFloatStateOf(0.6f) }

    val tiles = listOf(
        Tile("Wi-Fi", Icons.Rounded.Wifi, wifi.isWifiEnabled) {
            ctx.safeStart(Intent(Settings.ACTION_WIFI_SETTINGS))
        },
        Tile("Bluetooth", Icons.Rounded.Bluetooth, false) {
            ctx.safeStart(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        },
        Tile(
            "Torch",
            if (torchOn) Icons.Rounded.FlashlightOn else Icons.Rounded.FlashlightOff,
            torchOn,
        ) { torchOn = Torch.toggle(ctx) },
        Tile("Airplane", Icons.Rounded.AirplanemodeActive, false) {
            ctx.safeStart(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS))
        },
        Tile("Sound", Icons.Rounded.VolumeUp, false) {
            ctx.safeStart(Intent(Settings.ACTION_SOUND_SETTINGS))
        },
        Tile("Display", Icons.Rounded.BrightnessHigh, false) {
            ctx.safeStart(Intent(Settings.ACTION_DISPLAY_SETTINGS))
        },
        Tile("Camera", Icons.Rounded.CameraAlt, false) {
            ctx.safeStart(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            onClose()
        },
        Tile("Alarm", Icons.Rounded.Alarm, false) {
            ctx.safeStart(Intent(AlarmClock.ACTION_SHOW_ALARMS))
            onClose()
        },
    )

    val noRipple = remember { MutableInteractionSource() }

    Box(
        Modifier
            .fillMaxSize()
            .background(Kanai.scrim)
            .clickable(interactionSource = noRipple, indication = null, onClick = onClose)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp)
                // swallow taps on the panel so only the empty area closes it
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        now.format(ccTimeFmt),
                        color = Kanai.textPrimary,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Light,
                    )
                    Text(now.format(ccDateFmt), color = Kanai.textSecondary, fontSize = 13.sp)
                }
                IconButton(onClick = { ctx.safeStart(Intent(Settings.ACTION_SETTINGS)) }) {
                    Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Kanai.textPrimary)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Kanai.textPrimary)
                }
            }

            tiles.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    row.forEach { TileButton(it, Modifier.weight(1f)) }
                }
            }

            Spacer(Modifier.height(4.dp))

            SliderCard(
                icon = Icons.Rounded.BrightnessHigh,
                value = brightness,
                onChange = {
                    brightness = it
                    onBrightness(it.coerceIn(0.05f, 1f))
                },
            )
            SliderCard(
                icon = Icons.Rounded.VolumeUp,
                value = volume,
                onChange = {
                    volume = it
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).roundToInt(), 0)
                },
            )
        }
    }
}

@Composable
private fun TileButton(tile: Tile, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = tile.onClick,
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(
            Modifier
                .size(60.dp)
                .background(if (tile.active) Kanai.accent else Kanai.glassStrong, CircleShape),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                tile.icon,
                contentDescription = tile.label,
                tint = if (tile.active) Kanai.onAccent else Kanai.textPrimary,
            )
        }
        Text(tile.label, color = Kanai.textSecondary, fontSize = 11.sp)
    }
}

@Composable
private fun SliderCard(
    icon: ImageVector,
    value: Float,
    onChange: (Float) -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(24.dp))
            .padding(horizontal = 18.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = Kanai.textPrimary)
        Slider(
            value = value,
            onValueChange = onChange,
            colors = SliderDefaults.colors(
                thumbColor = Kanai.accent,
                activeTrackColor = Kanai.accent,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
            ),
            modifier = Modifier.padding(start = 12.dp),
        )
    }
}
