# Kanai Launcher

An original Android launcher with a home screen, app drawer, control centre and a custom lockscreen.
Built with Kotlin and Jetpack Compose. Design is Kanai's own: indigo, violet, rose and amber with glass cards.

## What is inside

- **Home screen**: greeting + clock card, 12 apps, dock (phone, messages, browser, camera).
- **App drawer**: swipe up on the home screen. Search box at the top, pull the handle down to close.
- **Control centre**: swipe down on the home screen. Wi-Fi, Bluetooth, Torch (real toggle), Airplane, Sound, Display, Camera, Alarm, plus brightness and volume sliders.
- **Lockscreen**: big clock and date, torch and camera shortcuts, swipe up to unlock.
- **Setup screen**: tap the gear on the home screen.

## How to build

1. Open the `NovaLauncher` folder in **Android Studio** (Koala or newer). It creates the Gradle wrapper for you.
2. Let Gradle sync, then press Run on a phone or emulator (Android 8.0+).
3. Press the Home button and choose **Kanai Launcher** (or use Setup step 1).

## Lockscreen: how it really works

Android does not allow third-party apps to replace the system lockscreen. Kanai does the next best thing:

1. A small foreground service listens for "screen off".
2. It opens `LockActivity` over the system keyguard, so when you wake the phone you see Kanai's lockscreen first.
3. Swipe up asks Android to dismiss the keyguard. If you have a PIN, pattern or fingerprint, Android asks for it. Your security is not bypassed.

To enable it: Setup, step 2 (allow display over other apps), then turn on the Kanai lockscreen switch.

Things this version does not do yet:

- Show notifications on the lockscreen (needs a `NotificationListenerService`).
- Replace the PIN entry screen itself (not possible for normal apps).
- Some phone brands kill background services aggressively. If the lockscreen stops appearing, set the battery option for Kanai to "Unrestricted".

## Project layout

```
app/src/main/java/com/nova/launcher/
  MainActivity.kt          home root, gestures, panels
  data/AppRepository.kt    installed apps, dock, launching
  ui/                      HomeScreen, AppDrawer, ControlCenter, SetupScreen, theme
  lock/                    LockService, LockActivity, LockScreen, BootReceiver
  util/Utils.kt            prefs, torch, helpers
```

## Customising

- Colours and gradient: `ui/Common.kt` (`object Kanai`).
- App name: `res/values/strings.xml`.
- Package name: change `namespace` and `applicationId` in `app/build.gradle.kts` and move the folders.
- App icon: replace `android:icon` in `AndroidManifest.xml` with your own.
